package com.plazoleta.usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Verifica que el contexto de Spring arranca con la configuración de pruebas (H2).
 */
@SpringBootTest
class PlazoletaUsuariosAplicacionTests {

    @Test
    void elContextoDeLaAplicacionArrancaSinErrores() {
    }
}
