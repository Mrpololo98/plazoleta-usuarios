package com.plazoleta.usuario.application.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.plazoleta.usuario.domain.exception.ReglaNegocioException;
import com.plazoleta.usuario.domain.model.Rol;
import com.plazoleta.usuario.domain.model.Usuario;
import com.plazoleta.usuario.domain.spi.CifradorClavesPuerto;
import com.plazoleta.usuario.domain.spi.RepositorioUsuariosPuerto;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Pruebas unitarias del caso de uso HU1 (JUnit 5 + Mockito).
 */
@ExtendWith(MockitoExtension.class)
class RegistradorPropietarioTest {

    @Mock
    private RepositorioUsuariosPuerto repositorioUsuarios;

    @Mock
    private CifradorClavesPuerto cifradorClaves;

    @InjectMocks
    private RegistradorPropietario registrador;

    private Usuario candidatoValido() {
        return new Usuario(null, "Laura", "Restrepo", "1020304050",
                "+573001234567", LocalDate.now().minusYears(30),
                "laura@demo-plazoleta.co", "Clave123*", null);
    }

    @Test
    void debeRegistrarPropietarioCuandoLosDatosSonValidos() {
        Usuario candidato = candidatoValido();
        when(repositorioUsuarios.existeCorreo(anyString())).thenReturn(false);
        when(repositorioUsuarios.existeDocumento(anyString())).thenReturn(false);
        when(cifradorClaves.proteger("Clave123*")).thenReturn("clave-protegida-simulada");
        Usuario persistido = new Usuario(9L, "Laura", "Restrepo", "1020304050",
                "+573001234567", LocalDate.now().minusYears(30),
                "laura@demo-plazoleta.co", "clave-protegida-simulada", Rol.PROPIETARIO);
        when(repositorioUsuarios.guardar(any(Usuario.class))).thenReturn(persistido);

        Usuario resultado = registrador.ejecutar(candidato);

        assertEquals(9L, resultado.getId());
        assertEquals(Rol.PROPIETARIO, resultado.getRol());
        verify(cifradorClaves).proteger("Clave123*");
        verify(repositorioUsuarios).guardar(any(Usuario.class));
    }

    @Test
    void debeRechazarDocumentoConLetras() {
        Usuario candidato = candidatoValido();
        candidato.setDocumentoIdentidad("10A20B");

        assertThatThrownBy(() -> registrador.ejecutar(candidato))
                .isInstanceOf(ReglaNegocioException.class)
                .hasMessageContaining("Documento inválido");
        verifyNoInteractions(repositorioUsuarios, cifradorClaves);
    }

    @Test
    void debeRechazarCelularConLetras() {
        Usuario candidato = candidatoValido();
        candidato.setCelular("300ABC");

        assertThatThrownBy(() -> registrador.ejecutar(candidato))
                .isInstanceOf(ReglaNegocioException.class)
                .hasMessageContaining("Celular inválido");
        verifyNoInteractions(repositorioUsuarios, cifradorClaves);
    }

    @Test
    void debeRechazarCelularExcesivo() {
        Usuario candidato = candidatoValido();
        candidato.setCelular("+5730012345678");

        assertThatThrownBy(() -> registrador.ejecutar(candidato))
                .isInstanceOf(ReglaNegocioException.class)
                .hasMessageContaining("Celular inválido");
        verifyNoInteractions(repositorioUsuarios, cifradorClaves);
    }

    @Test
    void debeRechazarCorreoMalFormado() {
        Usuario candidato = candidatoValido();
        candidato.setCorreo("laura-sin-arroba");

        assertThatThrownBy(() -> registrador.ejecutar(candidato))
                .isInstanceOf(ReglaNegocioException.class)
                .hasMessageContaining("Correo inválido");
        verifyNoInteractions(repositorioUsuarios, cifradorClaves);
    }

    @Test
    void debeRechazarMenorDeEdad() {
        Usuario candidato = candidatoValido();
        candidato.setFechaNacimiento(LocalDate.now().minusYears(17));

        assertThatThrownBy(() -> registrador.ejecutar(candidato))
                .isInstanceOf(ReglaNegocioException.class)
                .hasMessageContaining("mayor de edad");
        verifyNoInteractions(repositorioUsuarios, cifradorClaves);
    }

    @Test
    void debeRechazarCorreoDuplicado() {
        Usuario candidato = candidatoValido();
        when(repositorioUsuarios.existeCorreo("laura@demo-plazoleta.co")).thenReturn(true);

        assertThatThrownBy(() -> registrador.ejecutar(candidato))
                .isInstanceOf(ReglaNegocioException.class)
                .hasMessageContaining("ya registrado");
        verify(repositorioUsuarios, never()).guardar(any(Usuario.class));
        verifyNoInteractions(cifradorClaves);
    }
}
