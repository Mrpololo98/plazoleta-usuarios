package com.plazoleta.usuario.infrastructure.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repositorio Spring Data JPA de la entidad UsuarioEntidad.
 */
public interface RepositorioUsuariosJpa extends JpaRepository<UsuarioEntidad, Long> {

    boolean existsByCorreoIgnoreCase(String correo);

    boolean existsByDocumentoIdentidad(String documentoIdentidad);
}
