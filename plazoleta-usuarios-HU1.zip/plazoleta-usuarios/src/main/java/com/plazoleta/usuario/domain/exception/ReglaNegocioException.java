package com.plazoleta.usuario.domain.exception;

/**
 * Señala el incumplimiento de una regla de negocio de la plazoleta.
 */
public class ReglaNegocioException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ReglaNegocioException(String mensaje) {
        super(mensaje);
    }
}
