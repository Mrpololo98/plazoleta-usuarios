package com.plazoleta.usuario.domain.model;

/**
 * Perfiles disponibles dentro de la plazoleta de comidas.
 */
public enum Rol {

    ADMIN,
    PROPIETARIO,
    EMPLEADO,
    CLIENTE;

    /**
     * Autoridad con el prefijo que espera Spring Security al validar roles.
     */
    public String comoAutoridad() {
        return "ROLE_" + name();
    }
}
