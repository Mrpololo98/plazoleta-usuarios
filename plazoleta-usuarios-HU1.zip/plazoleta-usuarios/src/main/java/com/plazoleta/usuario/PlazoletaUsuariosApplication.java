package com.plazoleta.usuario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de arranque del microservicio de usuarios de la plazoleta.
 */
@SpringBootApplication
public class PlazoletaUsuariosApplication {

    public static void main(String[] args) {
        SpringApplication.run(PlazoletaUsuariosApplication.class, args);
    }
}
