package com.plazoleta.usuario.infrastructure.persistence;

import com.plazoleta.usuario.domain.model.Rol;
import com.plazoleta.usuario.domain.model.Usuario;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

/**
 * Traduce entre el modelo de dominio y la entidad JPA.
 */
@Mapper(componentModel = "spring")
public interface ConversorUsuarioPersistencia {

    @Mapping(target = "rol", source = "rol", qualifiedByName = "deRolATexto")
    UsuarioEntidad aEntidad(Usuario usuario);

    @Mapping(target = "rol", source = "rol", qualifiedByName = "deTextoARol")
    Usuario aDominio(UsuarioEntidad entidad);

    @Named("deRolATexto")
    default String deRolATexto(Rol rol) {
        return rol == null ? null : rol.name();
    }

    @Named("deTextoARol")
    default Rol deTextoARol(String texto) {
        return texto == null ? null : Rol.valueOf(texto);
    }
}
