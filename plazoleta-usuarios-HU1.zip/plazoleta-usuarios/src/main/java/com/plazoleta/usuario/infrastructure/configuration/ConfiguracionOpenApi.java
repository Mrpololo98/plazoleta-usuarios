package com.plazoleta.usuario.infrastructure.configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Personaliza la información general de la documentación OpenAPI.
 */
@Configuration
public class ConfiguracionOpenApi {

    @Bean
    public OpenAPI documentacionPlazoleta() {
        return new OpenAPI()
                .info(new Info()
                        .title("API de Usuarios · Plazoleta de Comidas")
                        .version("1.0.0")
                        .description("Servicio de registro de propietarios, empleados y clientes, "
                                + "así como autenticación de la plazoleta de comidas. "
                                + "Proyecto educativo con arquitectura hexagonal."));
    }
}
