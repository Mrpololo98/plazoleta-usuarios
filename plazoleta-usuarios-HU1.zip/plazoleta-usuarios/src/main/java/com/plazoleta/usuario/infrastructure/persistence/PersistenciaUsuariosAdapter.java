package com.plazoleta.usuario.infrastructure.persistence;

import com.plazoleta.usuario.domain.model.Usuario;
import com.plazoleta.usuario.domain.spi.RepositorioUsuariosPuerto;
import org.springframework.stereotype.Component;

/**
 * Adaptador de persistencia: implementa el puerto del dominio usando Spring Data JPA.
 */
@Component
public class PersistenciaUsuariosAdapter implements RepositorioUsuariosPuerto {

    private final RepositorioUsuariosJpa repositorioJpa;
    private final ConversorUsuarioPersistencia conversor;

    public PersistenciaUsuariosAdapter(RepositorioUsuariosJpa repositorioJpa,
                                        ConversorUsuarioPersistencia conversor) {
        this.repositorioJpa = repositorioJpa;
        this.conversor = conversor;
    }

    @Override
    public Usuario guardar(Usuario usuario) {
        UsuarioEntidad entidad = conversor.aEntidad(usuario);
        UsuarioEntidad guardada = repositorioJpa.save(entidad);
        return conversor.aDominio(guardada);
    }

    @Override
    public boolean existeCorreo(String correo) {
        return repositorioJpa.existsByCorreoIgnoreCase(correo);
    }

    @Override
    public boolean existeDocumento(String documentoIdentidad) {
        return repositorioJpa.existsByDocumentoIdentidad(documentoIdentidad);
    }
}
