package com.plazoleta.usuario.application.dto;

import com.plazoleta.usuario.domain.model.Rol;

/**
 * Vista pública de un usuario creado o consultado.
 * Nunca expone la clave ni el documento de identidad.
 */
public record RespuestaUsuario(
        Long id,
        String nombre,
        String apellido,
        String correo,
        Rol rol) {
}
