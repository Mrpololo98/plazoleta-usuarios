package com.plazoleta.usuario.infrastructure.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Representación relacional de un usuario (tabla: usuarios).
 * Solo existe en la capa de infraestructura: jamás sale por los endpoints.
 */
@Entity
@Table(name = "usuarios",
        uniqueConstraints = {
                @UniqueConstraint(name = "uq_usuarios_correo", columnNames = "correo"),
                @UniqueConstraint(name = "uq_usuarios_documento", columnNames = "documento_identidad")
        })
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioEntidad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", nullable = false, length = 60)
    private String nombre;

    @Column(name = "apellido", nullable = false, length = 60)
    private String apellido;

    @Column(name = "documento_identidad", nullable = false, length = 20)
    private String documentoIdentidad;

    @Column(name = "celular", nullable = false, length = 13)
    private String celular;

    @Column(name = "fecha_nacimiento", nullable = false)
    private LocalDate fechaNacimiento;

    @Column(name = "correo", nullable = false, length = 120)
    private String correo;

    @Column(name = "clave", nullable = false, length = 72)
    private String clave;

    @Column(name = "rol", nullable = false, length = 15)
    private String rol;
}
