package com.plazoleta.usuario.infrastructure.security;

import com.plazoleta.usuario.domain.spi.CifradorClavesPuerto;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Implementación del puerto de cifrado de claves usando BCrypt,
 * tal como lo exige la HU1.
 */
@Component
public class CifradorClavesBCrypt implements CifradorClavesPuerto {

    private final PasswordEncoder passwordEncoder;

    public CifradorClavesBCrypt(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public String proteger(String claveTextoPlano) {
        return passwordEncoder.encode(claveTextoPlano);
    }
}
