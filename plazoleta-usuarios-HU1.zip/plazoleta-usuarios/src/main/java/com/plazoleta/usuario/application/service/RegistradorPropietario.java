package com.plazoleta.usuario.application.service;

import com.plazoleta.usuario.domain.api.RegistrarPropietario;
import com.plazoleta.usuario.domain.exception.ReglaNegocioException;
import com.plazoleta.usuario.domain.model.Rol;
import com.plazoleta.usuario.domain.model.Usuario;
import com.plazoleta.usuario.domain.spi.CifradorClavesPuerto;
import com.plazoleta.usuario.domain.spi.RepositorioUsuariosPuerto;
import java.util.regex.Pattern;
import org.springframework.stereotype.Service;

/**
 * Caso de uso HU1: crea la cuenta de un propietario de restaurante.
 * Aplica las reglas de la historia de usuario y deja la clave protegida.
 */
@Service
public class RegistradorPropietario implements RegistrarPropietario {

    private static final Pattern SOLO_DIGITOS = Pattern.compile("\\d+");
    private static final Pattern CELULAR_PERMITIDO = Pattern.compile("\\+?\\d+");
    private static final Pattern CORREO_ESTRUCTURA = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");

    private final RepositorioUsuariosPuerto repositorioUsuarios;
    private final CifradorClavesPuerto cifradorClaves;

    public RegistradorPropietario(RepositorioUsuariosPuerto repositorioUsuarios,
                                  CifradorClavesPuerto cifradorClaves) {
        this.repositorioUsuarios = repositorioUsuarios;
        this.cifradorClaves = cifradorClaves;
    }

    @Override
    public Usuario ejecutar(Usuario candidato) {
        examinarDatos(candidato);
        descartarDuplicados(candidato);
        candidato.setClave(cifradorClaves.proteger(candidato.getClave()));
        candidato.setRol(Rol.PROPIETARIO);
        return repositorioUsuarios.guardar(candidato);
    }

    private void examinarDatos(Usuario candidato) {
        exigirPresente(candidato.getNombre(), "nombre");
        exigirPresente(candidato.getApellido(), "apellido");
        exigirPresente(candidato.getDocumentoIdentidad(), "documento de identidad");
        exigirPresente(candidato.getCelular(), "celular");
        exigirPresente(candidato.getCorreo(), "correo");
        exigirPresente(candidato.getClave(), "clave");
        if (candidato.getFechaNacimiento() == null) {
            throw new ReglaNegocioException("La fecha de nacimiento es un dato obligatorio");
        }
        if (!SOLO_DIGITOS.matcher(candidato.getDocumentoIdentidad()).matches()) {
            throw new ReglaNegocioException("Documento inválido: solo se permiten dígitos");
        }
        if (candidato.getCelular().length() > 13
                || !CELULAR_PERMITIDO.matcher(candidato.getCelular()).matches()) {
            throw new ReglaNegocioException(
                    "Celular inválido: use solo dígitos, un '+' inicial opcional y máximo 13 caracteres");
        }
        if (!CORREO_ESTRUCTURA.matcher(candidato.getCorreo()).matches()) {
            throw new ReglaNegocioException("Correo inválido: revise el formato del correo electrónico");
        }
        if (!candidato.esMayorDeEdad()) {
            throw new ReglaNegocioException("Registro no permitido: el propietario debe ser mayor de edad");
        }
    }

    private void descartarDuplicados(Usuario candidato) {
        if (repositorioUsuarios.existeCorreo(candidato.getCorreo())) {
            throw new ReglaNegocioException("Correo ya registrado en la plataforma");
        }
        if (repositorioUsuarios.existeDocumento(candidato.getDocumentoIdentidad())) {
            throw new ReglaNegocioException("Documento ya registrado en la plataforma");
        }
    }

    private void exigirPresente(String valor, String campo) {
        if (valor == null || valor.isBlank()) {
            throw new ReglaNegocioException("El campo " + campo + " no puede quedar vacío");
        }
    }
}
