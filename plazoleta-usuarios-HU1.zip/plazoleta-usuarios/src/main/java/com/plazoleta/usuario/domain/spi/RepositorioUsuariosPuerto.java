package com.plazoleta.usuario.domain.spi;

import com.plazoleta.usuario.domain.model.Usuario;

/**
 * Puerto de salida: persistencia de usuarios.
 * El dominio declara el contrato y la infraestructura lo implementa.
 */
public interface RepositorioUsuariosPuerto {

    Usuario guardar(Usuario usuario);

    boolean existeCorreo(String correo);

    boolean existeDocumento(String documentoIdentidad);
}
