package com.plazoleta.usuario.domain.model;

import java.time.LocalDate;

/**
 * Modelo de dominio de un usuario de la plazoleta de comidas.
 * Capa pura: sin anotaciones de Spring, JPA ni Lombok.
 */
public class Usuario {

    private static final int EDAD_MINIMA_EXIGIDA = 18;

    private Long id;
    private String nombre;
    private String apellido;
    private String documentoIdentidad;
    private String celular;
    private LocalDate fechaNacimiento;
    private String correo;
    private String clave;
    private Rol rol;

    public Usuario() {
    }

    public Usuario(Long id, String nombre, String apellido, String documentoIdentidad,
                   String celular, LocalDate fechaNacimiento, String correo,
                   String clave, Rol rol) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.documentoIdentidad = documentoIdentidad;
        this.celular = celular;
        this.fechaNacimiento = fechaNacimiento;
        this.correo = correo;
        this.clave = clave;
        this.rol = rol;
    }

    /**
     * Indica si la persona ya cumplió la mayoría de edad exigida por la plataforma.
     */
    public boolean esMayorDeEdad() {
        return fechaNacimiento != null
                && !fechaNacimiento.isAfter(LocalDate.now().minusYears(EDAD_MINIMA_EXIGIDA));
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDocumentoIdentidad() {
        return documentoIdentidad;
    }

    public void setDocumentoIdentidad(String documentoIdentidad) {
        this.documentoIdentidad = documentoIdentidad;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }
}
