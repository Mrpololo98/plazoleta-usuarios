package com.plazoleta.usuario.domain.api;

import com.plazoleta.usuario.domain.model.Usuario;

/**
 * Puerto de entrada de la HU1: registro de propietarios de restaurantes.
 */
public interface RegistrarPropietario {

    Usuario ejecutar(Usuario candidatoPropietario);
}
