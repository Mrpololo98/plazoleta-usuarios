package com.plazoleta.usuario.domain.spi;

/**
 * Puerto de salida: protección de claves en texto plano.
 */
public interface CifradorClavesPuerto {

    String proteger(String claveTextoPlano);
}
