package com.plazoleta.usuario.infrastructure.rest;

import com.plazoleta.usuario.application.dto.PeticionRegistrarUsuario;
import com.plazoleta.usuario.application.dto.RespuestaUsuario;
import com.plazoleta.usuario.domain.api.RegistrarPropietario;
import com.plazoleta.usuario.domain.model.Usuario;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Endpoints de la HU1: alta de propietarios de restaurantes por parte del administrador.
 * El controlador no contiene lógica: solo traduce y delega en el caso de uso.
 */
@RestController
@RequestMapping("/propietarios")
@Tag(name = "Propietarios", description = "Alta de propietarios de restaurantes en la plazoleta")
public class PropietarioControlador {

    private final RegistrarPropietario registrarPropietario;
    private final ConversorUsuariosRest conversor;

    public PropietarioControlador(RegistrarPropietario registrarPropietario,
                                  ConversorUsuariosRest conversor) {
        this.registrarPropietario = registrarPropietario;
        this.conversor = conversor;
    }

    @Operation(summary = "Crea la cuenta de un propietario",
            description = "Registra un nuevo propietario de restaurante aplicando las reglas de la HU1: "
                    + "documento con dígitos únicamente, celular de hasta 13 caracteres (un '+' inicial "
                    + "es opcional), correo con estructura válida, mayor de edad y clave protegida con BCrypt.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Propietario creado correctamente"),
            @ApiResponse(responseCode = "400", description = "Alguna regla de negocio no se cumplió")
    })
    @PostMapping
    public ResponseEntity<RespuestaUsuario> crear(@Valid @RequestBody PeticionRegistrarUsuario peticion) {
        Usuario candidato = conversor.aDominio(peticion);
        Usuario guardado = registrarPropietario.ejecutar(candidato);
        return ResponseEntity.status(HttpStatus.CREATED).body(conversor.aRespuesta(guardado));
    }
}
