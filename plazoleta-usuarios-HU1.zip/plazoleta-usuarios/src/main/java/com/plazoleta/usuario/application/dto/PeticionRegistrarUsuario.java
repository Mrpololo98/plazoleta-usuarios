package com.plazoleta.usuario.application.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * Datos de entrada para crear una cuenta de usuario (HU1).
 */
public record PeticionRegistrarUsuario(
        @NotBlank(message = "El nombre no puede quedar vacío") String nombre,
        @NotBlank(message = "El apellido no puede quedar vacío") String apellido,
        @NotBlank(message = "El documento de identidad no puede quedar vacío") String documentoIdentidad,
        @NotBlank(message = "El celular no puede quedar vacío") String celular,
        @NotNull(message = "La fecha de nacimiento no puede quedar vacía") LocalDate fechaNacimiento,
        @NotBlank(message = "El correo no puede quedar vacío") String correo,
        @NotBlank(message = "La clave no puede quedar vacía") String clave) {
}
