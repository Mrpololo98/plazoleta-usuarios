package com.plazoleta.usuario.infrastructure.rest;

import com.plazoleta.usuario.application.dto.PeticionRegistrarUsuario;
import com.plazoleta.usuario.application.dto.RespuestaUsuario;
import com.plazoleta.usuario.domain.model.Usuario;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * Traduce entre los DTO de entrada/salida y el modelo de dominio.
 */
@Mapper(componentModel = "spring")
public interface ConversorUsuariosRest {

    /**
     * Convierte la petición HTTP en un candidato del dominio.
     * El id lo genera la base y el rol lo fija el caso de uso.
     */
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "rol", ignore = true)
    Usuario aDominio(PeticionRegistrarUsuario peticion);

    RespuestaUsuario aRespuesta(Usuario usuario);
}
